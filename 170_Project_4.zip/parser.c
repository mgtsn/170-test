#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "parser.h"
#include "lexer.h"

static char token [20];


//function for indenting output
static void Space(int n)
{
	while(n > 0)
	{
		printf("  ");
		n--;
	}
}

static List S_Helper(int depth)
{
	List list;
	List current;
	if(!strncmp(token, "(", 20))
	{
		list = createCell(NULL);
		current = list;
		strcpy(token,getToken());
		//search for a close parentheses, printing out stuff inbetween
		while(strncmp(token, ")", 20))
		{
			

			
			current->car = S_Helper(depth + 1);
			current->cdr = createCell(NULL);
			current = current->cdr;
			//strcpy(token,getToken());
			
			
		}
		if(depth!=0)
		{
			strcpy(token,getToken());
		}
		
	}
	else
	{
		char* item = malloc(sizeof(char) * 20);
		strcpy(item, token);
		list = createCell(item);
		if(depth != 0)
		{
			strcpy(token, getToken());
		}
	}
	return list;
}

//calls start token and gets the first token
//calls the helper function with depth 0
List S_Expression()
{
	startTokens(20);
	strcpy(token, getToken());
	return S_Helper(0);
}

List SE2()
{
	strcpy(token, getToken());
	return S_Helper(0);
}

//Print helper function that does not print open parentheses
void printListNP(List l)
{
	if (l != NULL)
	{
		if (l->data != NULL)
		{
			printf("%s", l->data);
		}
		else
		{
			
			printList(l->car);

			if (l->cdr != NULL)
			{
				printf("%s", " ");
				printListNP(l->cdr);
			}
			else
			{
				printf("%s", ")");
			}
		}
	}
}

//Print function that does print open parentheses
void printList(List l)
{
	if (l != NULL)
	{
		if (l->data != NULL)
		{
			printf("%s", l->data);
		}
		else
		{
			printf("%s", "(");
			printList(l->car);

			if (l->cdr != NULL)
			{
				printf("%s", " ");
				printListNP(l->cdr);
			}
			else
			{
				printf("%s", ")");
			}
		}
	}
}




