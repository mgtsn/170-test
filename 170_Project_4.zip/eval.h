#ifndef PARSER
#define PARSER
#include <stdlib.h>
#include "cell.h"

List car(List l);

List cdr(List l);

List quote(List l);

List cons(List l, List t);

List eval(List l);

#endif
