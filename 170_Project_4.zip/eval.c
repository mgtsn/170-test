#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "parser.h"
#include "lexer.h"



List car(List l)
{
	return l->car;
}

List cdr(List l)
{
	return l->cdr;
}

List quote(List l)
{
	
	return l;
}

List cons(List l, List t)
{
	List temp = createCell(NULL);
	temp->car = l;
	temp->cdr = t;
	return temp;
}

List symbol(List l)
{
	if(l->car == NULL && l->cdr == NULL)
	{
		return createCell("#t");
	}
	return createCell("()");
}

List append(List l, List t)
{
	if(l == NULL)
	{
		return t;
	}
	return cons(l->car, append(l->cdr, t));
}

List null(List l)
{
	if(l == NULL)
	{
		return createCell("#t");
	}
	if(!strncmp(l->data, "()", 20) || !strncmp(l->data, "#f", 20))
	{
		return createCell("#t");
	}
	return createCell("()");
}

int eHelper(List l, List t)
{
	if(l == NULL && t == NULL)
	{
		return 1;
	}
	if(l == NULL && t != NULL)
	{
		return 0;
	}
	if(l != NULL && t == NULL)
	{
		return 0;
	}
	if((l->data ==NULL) != (t->data == NULL))
	{
		return 0;
	}
	if(l->data != NULL && t->data != NULL)
	{
		if(strncmp(l->data, t->data, 20))
		{
			return 0;
		}
	}
	if(l->cdr == NULL && l->car == NULL && t->cdr == NULL && t->car == NULL)
	{
		return 1;
	}
	return (eHelper(l->car, t->car) && eHelper(l->cdr, t->cdr));
}

List equal(List l, List t)
{
	if(eHelper(l->car, t->car) && eHelper(l->cdr, t->cdr))
	{
		return createCell("#t");
	}
	return createCell("()");
}

List assoc(List key, List l)
{
	List current = l;
	List temp;
	int i = 1;
	while(i)
	{
		if(current->car != NULL)
		{
			temp = current->car;
			if(!strncmp(temp->car->data, key->data, 20))
			{
				return temp;
			}
		}
		if(current->cdr == NULL)
		{
			i = 0;
		}
		else
		{
			current = current->cdr;
		}
	}
	return createCell("#f");
}

List eval(List l)
{
	if(l != NULL)
	{
		
		if(l->car != NULL && l->car->data != NULL)
		{
			if(!strncmp(l->car->data, "car", 20))
			{

				return car(eval(l->cdr->car));
			}
			if(!strncmp(l->car->data, "cdr", 20))
			{
				return cdr(eval(l->cdr->car));
			}
			if(!strncmp(l->car->data, "quote", 20) || !strncmp(l->car->data, "'", 20))
			{
				return l->cdr->car;
			}
			if(!strncmp(l->car->data, "cons", 20))
			{
				return cons(eval(l->cdr->car), eval(l->cdr->cdr->car));
			}
			if(!strncmp(l->car->data, "symbol?", 20))
			{
				return symbol(eval(l->cdr->car));
			}
			if(!strncmp(l->car->data, "append", 20))
			{
				return append(eval(l->cdr->car), eval(l->cdr->cdr->car));
			}
			if(!strncmp(l->car->data, "null?", 20))
			{
				return null(eval(l->cdr->car));
			}
			if(!strncmp(l->car->data, "equal?", 20))
			{
				printList(l->cdr->cdr->car);
				printf("\n");
				printList(l->cdr->cdr->cdr->cdr->car);
				printf("\n");
				return equal(eval(l->cdr->car), eval(l->cdr->cdr->car));
			}
			if(!strncmp(l->car->data, "assoc", 20))
			{
				return assoc(eval(l->cdr->car), l->cdr->cdr->car);
			}
		}
	}
	return l;

}
