#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "parser.h"
#include "lexer.h"
#include "cell.h"
#include "eval.h"

int main(int argc, const char * argv[]) {
	
	List l = createCell(NULL);
	while (1)
	{
		//Infinitely read expressions from the user, analyze them, and print them out
		printf("scheme> ");
		l = S_Expression();
		//printf("%s\n", l->car->data);
		l = eval(l);
		//printf("%s\n", "test2");
		printList(l);
		printf("\n");
	}
    return 0;
}
